package com.EntrioServer.app.literals;

public enum ActivityStatus {
    ACTIVE,
    INACTIVE,
    RESTRICTED,
    VERIFIED,
    UNVERIFIED
}
