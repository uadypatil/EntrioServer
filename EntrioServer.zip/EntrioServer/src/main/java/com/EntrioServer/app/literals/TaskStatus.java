package com.EntrioServer.app.literals;

public enum TaskStatus {
    ASSIGNED,
    ONGOING,
    PENDING,
    COMPLETED,
    CANCELLED
}
