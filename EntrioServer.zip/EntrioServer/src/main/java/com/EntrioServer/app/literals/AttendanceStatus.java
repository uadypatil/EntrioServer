package com.EntrioServer.app.literals;

public enum AttendanceStatus {
    FULL_DAY,
    HALF_DAY,
    LOP,        // LOSS OF PAY
    ON_LEAVE,
    UNDEFINED,
    OTHER,
    SITLL_UNDEFINED
}
