import React from "react";
import { COLORS } from "../config/theme";

const Help = () => {
    return (
        <div
            data-aos="fade-up"
            style={{
                background: COLORS.surface,
                border: `1px solid ${COLORS.border}`,
                borderRadius: 12,
                padding: 24,
                height: "90%", 
                minHeight: "90%", 
                overflowY: "auto",
                fontFamily: "'Segoe UI', Tahoma, sans-serif",
            }}
        >
            {/* Header */}
            <h2
                style={{
                    marginBottom: 8,
                    color: COLORS.textPrimary,
                    fontWeight: 700,
                }}
            >
                Help & Support
            </h2>

            <p
                style={{
                    marginBottom: 24,
                    color: COLORS.textSecondary,
                    maxWidth: 700,
                }}
            >
                This section helps you understand how to use the application features
                efficiently. If you face any issues, refer to the relevant section
                below.
            </p>

            {/* Sections */}
            <div style={{ display: "grid", gap: 20 }}>
                {/* Dashboard */}
                <HelpCard
                    title="Dashboard"
                    content="Track your daily working hours by entering In-Time and Out-Time.
          Progress is automatically calculated for Half Day (5 hrs) and Full Day (9 hrs)."
                />

                {/* Monthly Sheet */}
                <HelpCard
                    title="Monthly Sheet"
                    content="View and update your day-wise work details including tasks, assigned
          person, remarks, and time logs for the selected month."
                />

                {/* Reports */}
                <HelpCard
                    title="Reports"
                    content="Filter End-of-Day (EOD) reports by month and year. Download reports
          in PDF or Excel format for sharing or record keeping."
                />

                {/* Settings */}
                <HelpCard
                    title="Settings"
                    content="Manage application preferences and personal configurations.
          Changes apply immediately after saving."
                />

                {/* Support */}
                <HelpCard
                    title="Need More Help?"
                    content="If you encounter technical issues or data discrepancies, please
          contact your system administrator or support team."
                    highlight
                />
            </div>
        </div>
    );
};

const HelpCard = ({ title, content, highlight }) => (
    <div
        data-aos="fade-up"
        style={{
            background: highlight ? COLORS.hover : COLORS.white,
            border: `1px solid ${COLORS.border}`,
            borderRadius: 10,
            padding: 16,
            transition: "transform 0.2s ease",
        }}
    >
        <h4
            style={{
                marginBottom: 6,
                color: COLORS.textPrimary,
                fontWeight: 600,
            }}
        >
            {title}
        </h4>
        <p
            style={{
                margin: 0,
                color: COLORS.textSecondary,
                lineHeight: 1.6,
            }}
        >
            {content}
        </p>
    </div>
);

export default Help;
