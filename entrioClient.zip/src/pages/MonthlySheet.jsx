import React, { useState } from "react";
import { COLORS } from "../config/theme";

const MonthlySheet = ({ year, month }) => {
  const days = new Date(year, month + 1, 0).getDate();

  const [rows, setRows] = useState(
    Array.from({ length: days }, (_, i) => ({
      date: new Date(year, month, i + 1),
      task: "",
      assignedBy: "",
      remarks: "",
      timeIn: "",
      timeOut: "",
    }))
  );

  const handleChange = (i, field, value) => {
    const copy = [...rows];
    copy[i][field] = value;
    setRows(copy);
  };

  return (
    <div
      data-aos="fade-up"
      style={{
        padding: 20,
        overflow: "auto",
        height: "90vh",
      }}
    >
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          background: COLORS.white,
        }}
      >
        <thead>
          <tr>
            {["Date", "Task", "Assigned By", "Remarks", "Time In", "Time Out"].map(
              (h) => (
                <th
                  key={h}
                  style={{
                    padding: 10,
                    borderBottom: `2px solid ${COLORS.border}`,
                    color: COLORS.textPrimary,
                    background: COLORS.surface,
                  }}
                >
                  {h}
                </th>
              )
            )}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} data-aos="fade-up">
              <td style={cell}>{r.date.toLocaleDateString()}</td>
              {["task", "assignedBy", "remarks"].map((f) => (
                <td key={f} style={cell}>
                  <input
                    value={r[f]}
                    onChange={(e) => handleChange(i, f, e.target.value)}
                    style={input}
                  />
                </td>
              ))}
              {["timeIn", "timeOut"].map((f) => (
                <td key={f} style={cell}>
                  <input
                    type="time"
                    value={r[f]}
                    onChange={(e) => handleChange(i, f, e.target.value)}
                    style={input}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const cell = {
  padding: 8,
  borderBottom: `1px solid #E1E4E8`,
  textAlign: "center",
};

const input = {
  width: "100%",
  border: "none",
  background: "transparent",
  outline: "none",
  textAlign: "center",
};

export default MonthlySheet;
