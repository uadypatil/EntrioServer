const Settings = () => <h2>Settings</h2>;
export default Settings;
