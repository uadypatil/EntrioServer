import React, { useEffect, useState } from "react";
import { COLORS } from "../config/theme";
import { getTodayEOD, fillTodayEOD, patchTodayEOD } from "../integrator/eodApi";
import { ATTENDENCE_STATUS } from "../literals/attendenceStatusLit";

const HOURS_HALF_DAY = 5;
const HOURS_FULL_DAY = 9;
const USER_ID = 1; // Replace with dynamic logged-in user ID if needed

const Dashboard = () => {
    const [timeIn, setTimeIn] = useState("");
    const [timeOut, setTimeOut] = useState("");
    const [workedHours, setWorkedHours] = useState(0);
    const [task, setTask] = useState("");
    const [assignedBy, setAssignedBy] = useState("");
    const [remarks, setRemarks] = useState("");
    const [eodExists, setEodExists] = useState(false); // track if today's EOD exists

    /* ================= FETCH TODAY RECORD ================= */
    useEffect(() => {
        const fetchToday = async () => {
            try {
                const data = await getTodayEOD(USER_ID);
                if (data) {
                    setTimeIn(data.timeIn?.substring(0, 5) || "");
                    setTimeOut(data.timeOut?.substring(0, 5) || "");
                    setTask(data.todaysWork || "");
                    setAssignedBy(data.assignedBy || "");
                    setRemarks(data.remarks || "");
                    setEodExists(true);
                }
            } catch (err) {
                // no record → keep blank
                setEodExists(false);
            }
        };

        fetchToday();
    }, []);

    /* ================= AUTO SAVE FUNCTION ================= */
    const autoSave = async (updatedFields) => {
        try {
            // Determine effective timeIn and timeOut values (from updatedFields or current state)
            const effectiveTimeIn = updatedFields.timeIn !== undefined ? updatedFields.timeIn : timeIn || "";
            const effectiveTimeOut = updatedFields.timeOut !== undefined ? updatedFields.timeOut : timeOut || "";

            // Calculate worked hours if timeIn is present
            let attendanceStatus = ATTENDENCE_STATUS.SITLL_UNDEFINED;

            if (effectiveTimeIn && effectiveTimeOut) {
                // Parse hours and minutes from time strings (HH:mm)
                const [inH, inM] = effectiveTimeIn.split(":").map(Number);
                const [outH, outM] = effectiveTimeOut.split(":").map(Number);

                // Create Date objects for calculation (use same day)
                const start = new Date();
                start.setHours(inH, inM, 0, 0);

                const end = new Date();
                end.setHours(outH, outM, 0, 0);

                // Calculate difference in hours
                let diffHrs = (end - start) / (1000 * 60 * 60);

                if (diffHrs < 5) {
                    attendanceStatus = ATTENDENCE_STATUS.LOP;
                } else if (diffHrs >= 5 && diffHrs < 8.5) {
                    attendanceStatus = ATTENDENCE_STATUS.HALF_DAY;
                } else if (diffHrs >= 8.5) {
                    attendanceStatus = ATTENDENCE_STATUS.FULL_DAY;
                }
            }

            // If timeOut not defined, keep status as still undefined (per your request)
            if (!effectiveTimeOut) {
                attendanceStatus = ATTENDENCE_STATUS.SITLL_UNDEFINED;
            }

            // Construct payload with all fields, using updated or current state values
            const payload = {
                timeIn: effectiveTimeIn,
                timeOut: effectiveTimeOut,
                todaysWork:
                    updatedFields.todaysWork !== undefined ? updatedFields.todaysWork : task || "",
                assignedBy:
                    updatedFields.assignedBy !== undefined ? updatedFields.assignedBy : assignedBy || "",
                remarks:
                    updatedFields.remarks !== undefined ? updatedFields.remarks : remarks || "",
                attendanceStatus,
                desktopUserId: USER_ID, // Always include the user ID
                monthId: 0, // Optional: set monthId if needed
            };

            if (eodExists) {
                await patchTodayEOD(USER_ID, payload);
            } else {
                await fillTodayEOD(USER_ID, payload);
                setEodExists(true); // record now exists
            }
        } catch (err) {
            console.error("Auto save failed", err);
        }
    };



    /* ================= TIME CALCULATION ================= */
    useEffect(() => {
        if (!timeIn) return;

        const interval = setInterval(() => {
            const start = new Date();
            const [h, m] = timeIn.split(":");
            start.setHours(h, m, 0, 0);

            const end = timeOut
                ? new Date(start.toDateString() + " " + timeOut)
                : new Date();

            const diffMs = end - start;
            const hrs = Math.max(diffMs / (1000 * 60 * 60), 0);

            setWorkedHours(hrs);
        }, 1000);

        return () => clearInterval(interval);
    }, [timeIn, timeOut]);

    /* ================= STATUS ================= */
    const progressPercent = Math.min((workedHours / HOURS_FULL_DAY) * 100, 100);

    const getStatus = () => {
        if (workedHours >= HOURS_FULL_DAY) return "Full Day Completed";
        if (workedHours >= HOURS_HALF_DAY) return "Half Day Completed";
        return "Working...";
    };

    const getProgressColor = () => {
        if (workedHours >= HOURS_FULL_DAY) return COLORS.success;
        if (workedHours >= HOURS_HALF_DAY) return COLORS.warning;
        return COLORS.primary;
    };

    /* ================= UI ================= */
    return (
        <div
            style={{
                display: "flex",
                gap: 20,
                height: "auto",
            }}
        >
            {/* LEFT PANEL */}
            <div
                style={{
                    flex: 1,
                    background: COLORS.surface,
                    border: `1px solid ${COLORS.border}`,
                    borderRadius: 10,
                    padding: 20,
                }}
            >
                <h3 style={{ color: COLORS.textPrimary, marginBottom: 20 }}>
                    Attendance
                </h3>

                <div style={{ display: "flex", gap: 12, marginBottom: 20 }}>
                    <div>
                        <label style={label}>Time In</label>
                        <input
                            type="time"
                            value={timeIn}
                            onChange={(e) => setTimeIn(e.target.value)}
                            onBlur={() => autoSave({ timeIn })}
                            style={input}
                        />
                    </div>

                    <div>
                        <label style={label}>Time Out</label>
                        <input
                            type="time"
                            value={timeOut}
                            onChange={(e) => setTimeOut(e.target.value)}
                            onBlur={() => autoSave({ timeOut })}
                            style={input}
                        />
                    </div>
                </div>

                <div style={{ marginBottom: 10 }}>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <span style={{ fontWeight: 600, color: COLORS.textPrimary }}>
                            {getStatus()}
                        </span>
                        <span style={{ color: COLORS.textSecondary }}>
                            {workedHours.toFixed(2)} hrs
                        </span>
                    </div>

                    <div
                        style={{
                            marginTop: 8,
                            height: 12,
                            background: COLORS.border,
                            borderRadius: 6,
                            overflow: "hidden",
                        }}
                    >
                        <div
                            style={{
                                width: `${progressPercent}%`,
                                height: "100%",
                                background: `linear-gradient(90deg, ${getProgressColor()}, ${COLORS.hover})`,
                                transition: "width 0.5s ease",
                            }}
                        />
                    </div>
                </div>
            </div>

            {/* RIGHT PANEL */}
            <div
                style={{
                    flex: 1.2,
                    background: COLORS.surface,
                    border: `1px solid ${COLORS.border}`,
                    borderRadius: 10,
                    padding: 20,
                }}
            >
                <h3 style={{ color: COLORS.textPrimary, marginBottom: 20 }}>
                    Today’s Work
                </h3>

                <textarea
                    placeholder="Enter work done today or planned tasks..."
                    value={task}
                    onChange={(e) => setTask(e.target.value)}
                    onBlur={() => autoSave({ todaysWork: task })}
                    style={{
                        width: "90%",
                        height: "200px",
                        borderRadius: 8,
                        border: `1px solid ${COLORS.border}`,
                        padding: 12,
                        fontSize: 14,
                        resize: "none",
                        outline: "none",
                        fontFamily: "inherit",
                    }}
                />

                <div>
                    <h3 style={{ color: COLORS.textPrimary, marginBottom: 20 }}>
                        Assigned By
                    </h3>
                    <input
                        type="text"
                        value={assignedBy}
                        onChange={(e) => setAssignedBy(e.target.value)}
                        onBlur={() => autoSave({ assignedBy })}
                        style={inputText}
                        placeholder="Task Assigned By"
                    />
                </div>

                <div>
                    <h3 style={{ color: COLORS.textPrimary, marginBottom: 20 }}>
                        Remarks
                    </h3>
                    <input
                        type="text"
                        value={remarks}
                        onChange={(e) => setRemarks(e.target.value)}
                        onBlur={() => autoSave({ remarks })}
                        style={inputText}
                        placeholder="Remarks"
                    />
                </div>
            </div>
        </div>
    );
};

/* ================= STYLES ================= */
const label = {
    display: "block",
    marginBottom: 6,
    color: COLORS.textSecondary,
    fontSize: 13,
};

const input = {
    padding: "8px 10px",
    borderRadius: 6,
    border: `1px solid ${COLORS.border}`,
    outline: "none",
};

const inputText = {
    width: "90%",
    padding: "8px 10px",
    borderRadius: 6,
    border: `1px solid ${COLORS.border}`,
    outline: "none",
};

export default Dashboard;
