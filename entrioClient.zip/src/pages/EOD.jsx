import React, { useEffect, useState } from "react";
import { COLORS } from "../config/theme";
import { getAllEOD } from "../integrator/eodApi";
import { ATTENDENCE_STATUS } from "../literals/attendenceStatusLit";

const EOD = () => {
    const [records, setRecords] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchRecords = async () => {
            try {
                const data = await getAllEOD();
                if (Array.isArray(data)) {
                    const sorted = data.sort((a, b) => new Date(b.date) - new Date(a.date));
                    setRecords(sorted);
                } else {
                    setRecords([]);
                }
            } catch (err) {
                setError("Failed to fetch EOD records.");
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchRecords();
    }, []);

    const displayField = (value) => (value ? value : "NA");

    const getStatusColor = (status) => {
        switch (status) {
            case ATTENDENCE_STATUS.FULL_DAY:
                return "green";
            case ATTENDENCE_STATUS.HALF_DAY:
                return "orange";
            case ATTENDENCE_STATUS.LOP:
                return "red";
            case ATTENDENCE_STATUS.ON_LEAVE:
                return "blue";
            case ATTENDENCE_STATUS.UNDEFINED:
            case ATTENDENCE_STATUS.SITLL_UNDEFINED:
                return "gray";
            default:
                return "black";
        }
    };

    if (loading) {
        return (
            <div style={card}>
                <h3 style={title}>EOD</h3>
                <p style={{ color: COLORS.textSecondary }}>Loading records...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div style={card}>
                <h3 style={title}>EOD</h3>
                <p style={{ color: "red" }}>{error}</p>
            </div>
        );
    }

    return (
        <div style={card}>
            <h3 style={title}>EOD</h3>

            <div style={{ overflowX: "auto" }}>
                <table style={table}>
                    <thead>
                        <tr>
                            <th style={th}>#</th>
                            <th style={th}>Date</th>
                            <th style={th}>Task</th>
                            <th style={th}>In Time</th>
                            <th style={th}>Out Time</th>
                            <th style={th}>Assigned By</th>
                            <th style={th}>Remarks</th>
                            <th style={th}>Attendance Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        {records.length === 0 ? (
                            <tr>
                                <td colSpan="8" style={empty}>
                                    No EOD records found
                                </td>
                            </tr>
                        ) : (
                            records.map((r, index) => (
                                <tr key={r.id} style={row}>
                                    <td style={td}>{index + 1}</td>
                                    <td style={td}>{displayField(r.date)}</td>
                                    <td style={td}>{displayField(r.todaysWork || r.task)}</td>
                                    <td style={td}>{displayField(r.timeIn || r.inTime)}</td>
                                    <td style={td}>{displayField(r.timeOut || r.outTime)}</td>
                                    <td style={td}>{displayField(r.assignedBy)}</td>
                                    <td style={td}>{displayField(r.remarks)}</td>
                                    <td style={td}>
                                        <span
                                            style={{
                                                color: getStatusColor(r.attendanceStatus),
                                                fontWeight: 600,
                                            }}
                                        >
                                            {displayField(r.attendanceStatus)}
                                        </span>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

/* ===== Styles ===== */
const card = {
    background: COLORS.surface,
    border: `1px solid ${COLORS.border}`,
    borderRadius: 10,
    padding: 20,
};

const title = {
    color: COLORS.textPrimary,
    marginBottom: 20,
};

const table = {
    width: "100%",
    borderCollapse: "collapse",
};

const th = {
    padding: 10,
    textAlign: "left",
    color: COLORS.textSecondary,
    borderBottom: `1px solid ${COLORS.border}`,
};

const td = {
    padding: 10,
    borderBottom: `1px solid ${COLORS.border}`,
    color: COLORS.textPrimary,
    verticalAlign: "top",
};

const row = {
    height: 44,
};

const empty = {
    padding: 20,
    textAlign: "center",
    color: COLORS.textSecondary,
};

export default EOD;
