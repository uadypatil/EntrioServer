import React, { useState } from "react";
import { COLORS } from "../config/theme";

const MonthManager = () => {
    const [months, setMonths] = useState([]);
    const [monthName, setMonthName] = useState("");
    const [year, setYear] = useState("");

    const [editId, setEditId] = useState(null);
    const [editMonth, setEditMonth] = useState("");
    const [editYear, setEditYear] = useState("");

    /* ===== Add Month ===== */
    const addMonth = () => {
        if (!monthName || !year) return;

        setMonths([
            ...months,
            {
                id: Date.now(),
                monthName,
                year,
                addedOn: new Date().toLocaleDateString(),
            },
        ]);

        setMonthName("");
        setYear("");
    };

    /* ===== Edit Handlers ===== */
    const startEdit = (m) => {
        setEditId(m.id);
        setEditMonth(m.monthName);
        setEditYear(m.year);
    };

    const saveEdit = (id) => {
        setMonths(
            months.map((m) =>
                m.id === id
                    ? { ...m, monthName: editMonth, year: editYear }
                    : m
            )
        );
        cancelEdit();
    };

    const cancelEdit = () => {
        setEditId(null);
        setEditMonth("");
        setEditYear("");
    };

    const deleteMonth = (id) => {
        setMonths(months.filter((m) => m.id !== id));
    };

    return (
        <div style={card}>
            <h3 style={title}>Month Manager</h3>

            {/* ===== Add Section ===== */}
            <div style={row}>
                <input
                    placeholder="Month"
                    value={monthName}
                    onChange={(e) => setMonthName(e.target.value)}
                    style={input}
                />
                <input
                    placeholder="Year"
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    style={input}
                />
                <button onClick={addMonth} style={primaryBtn}>
                    Add
                </button>
            </div>

            {/* ===== Table ===== */}
            <table style={table}>
                <thead>
                    <tr>
                        <th style={th}>Month</th>
                        <th style={th}>Year</th>
                        <th style={th}>Added On</th>
                        <th style={th}>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {months.length === 0 ? (
                        <tr>
                            <td colSpan="4" style={empty}>
                                No months added
                            </td>
                        </tr>
                    ) : (
                        months.map((m) => (
                            <tr key={m.id}>
                                <td style={td}>
                                    {editId === m.id ? (
                                        <input
                                            value={editMonth}
                                            onChange={(e) => setEditMonth(e.target.value)}
                                            style={editInput}
                                        />
                                    ) : (
                                        m.monthName
                                    )}
                                </td>

                                <td style={td}>
                                    {editId === m.id ? (
                                        <input
                                            value={editYear}
                                            onChange={(e) => setEditYear(e.target.value)}
                                            style={editInput}
                                        />
                                    ) : (
                                        m.year
                                    )}
                                </td>

                                <td style={td}>{m.addedOn}</td>

                                <td style={td}>
                                    {editId === m.id ? (
                                        <>
                                            <button
                                                onClick={() => saveEdit(m.id)}
                                                style={saveBtn}
                                            >
                                                Save
                                            </button>
                                            <button onClick={cancelEdit} style={cancelBtn}>
                                                Cancel
                                            </button>
                                        </>
                                    ) : (
                                        <>
                                            <button
                                                onClick={() => startEdit(m)}
                                                style={editBtn}
                                            >
                                                Edit
                                            </button>
                                            <button
                                                onClick={() => deleteMonth(m.id)}
                                                style={deleteBtn}
                                            >
                                                Delete
                                            </button>
                                        </>
                                    )}
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
    );
};

/* ===== Styles ===== */

const card = {
    background: COLORS.surface,
    border: `1px solid ${COLORS.border}`,
    borderRadius: 10,
    padding: 20,
};

const title = {
    color: COLORS.textPrimary,
    marginBottom: 20,
};

const row = {
    display: "flex",
    gap: 12,
    marginBottom: 20,
};

const input = {
    padding: "8px 10px",
    borderRadius: 6,
    border: `1px solid ${COLORS.border}`,
    outline: "none",
};

const editInput = {
    ...input,
    width: "90%",
};

const primaryBtn = {
    background: COLORS.primary,
    color: "#fff",
    border: "none",
    padding: "8px 14px",
    borderRadius: 6,
    cursor: "pointer",
};

const table = {
    width: "100%",
    borderCollapse: "collapse",
};

const th = {
    padding: 10,
    textAlign: "left",
    color: COLORS.textSecondary,
    borderBottom: `1px solid ${COLORS.border}`,
};

const td = {
    padding: 10,
    borderBottom: `1px solid ${COLORS.border}`,
    color: COLORS.textPrimary,
};

const editBtn = {
    marginRight: 8,
    padding: "4px 10px",
    borderRadius: 5,
    border: `1px solid ${COLORS.border}`,
    background: COLORS.surface,
    cursor: "pointer",
};

const saveBtn = {
    marginRight: 8,
    padding: "4px 10px",
    borderRadius: 5,
    border: "none",
    background: COLORS.success,
    color: "#fff",
    cursor: "pointer",
};

const cancelBtn = {
    marginRight: 8,
    padding: "4px 10px",
    borderRadius: 5,
    border: `1px solid ${COLORS.border}`,
    background: COLORS.surface,
    cursor: "pointer",
};

const deleteBtn = {
    padding: "4px 10px",
    borderRadius: 5,
    border: "none",
    background: COLORS.error,
    color: "#fff",
    cursor: "pointer",
};

const empty = {
    padding: 20,
    textAlign: "center",
    color: COLORS.textSecondary,
};

export default MonthManager;
