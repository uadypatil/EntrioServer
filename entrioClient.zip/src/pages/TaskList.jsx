import React, { useState } from "react";
import { COLORS } from "../config/theme";
// import { insertTask } from "../utils/useMonthManager";

const STATUS_OPTIONS = [
    "Assigned",
    "Ongoing",
    "Pending",
    "Completed",
    "Canceled",
];

const TaskList = () => {
    const [tasks, setTasks] = useState([
        {
            id: 1,
            task: "API integration for attendance module",
            assignedBy: "Sanket Praname",
            assignedOn: "2026-01-22 09:30",
            status: "Assigned",
            statusUpdatedOn: "2026-01-22 09:30",
        },
    ]);

    const [editingTask, setEditingTask] = useState(null);

    /* ===== Helpers ===== */
    const now = () =>
        new Date().toISOString().slice(0, 16).replace("T", " ");

    const saveTask = (task) => {
        if (task.id) {
            setTasks((prev) =>
                prev.map((t) => (t.id === task.id ? task : t))
            );
        } else {
            setTasks((prev) => [
                ...prev,
                { ...task, id: Date.now() },
            ]);
        }
        setEditingTask(null);
    };

    const updateStatus = (id, status) => {
        setTasks((prev) =>
            prev.map((t) =>
                t.id === id
                    ? { ...t, status, statusUpdatedOn: now() }
                    : t
            )
        );
    };

    const handleAddTask = () => {
        // insertTask();
    }

    return (
        <div style={card}>
            <div style={header}>
                <h3 style={title}>Task List</h3>
                <button style={addBtn} onClick={() => { setEditingTask({}), handleAddTask() }}>
                    + Add Task
                </button>
            </div>

            <table style={table}>
                <thead>
                    <tr>
                        <th style={th}>Sr No</th>
                        <th style={th}>Task</th>
                        <th style={th}>Assigned By</th>
                        <th style={th}>Assigned On</th>
                        <th style={th}>Status</th>
                        <th style={th}>Status Updated On</th>
                        <th style={th}>Action</th>
                    </tr>
                </thead>

                <tbody>
                    {tasks.map((t, i) => (
                        <tr key={t.id}>
                            <td style={td}>{i + 1}</td>
                            <td style={td}>{t.task}</td>
                            <td style={td}>{t.assignedBy}</td>
                            <td style={td}>{t.assignedOn}</td>
                            <td style={td}>
                                <select
                                    value={t.status}
                                    onChange={(e) => updateStatus(t.id, e.target.value)}
                                    style={{
                                        ...select,
                                        color: STATUS_COLORS[t.status],
                                        border: `1px solid ${STATUS_COLORS[t.status]}`,
                                        fontWeight: 600,
                                    }}
                                >
                                    {STATUS_OPTIONS.map((s) => (
                                        <option key={s} value={s} style={{ color: STATUS_COLORS[s] }}>
                                            {s}
                                        </option>
                                    ))}
                                </select>
                            </td>

                            <td style={td}>{t.statusUpdatedOn}</td>
                            <td style={td}>
                                <button
                                    style={editBtn}
                                    onClick={() => setEditingTask(t)}
                                >
                                    Edit
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {editingTask !== null && (
                <TaskForm
                    task={editingTask}
                    onSave={saveTask}
                    onClose={() => setEditingTask(null)}
                />
            )}
        </div>
    );
};

/* ===== Add/Edit Form ===== */
const TaskForm = ({ task, onSave, onClose }) => {
    const [form, setForm] = useState({
        task: task.task || "",
        assignedBy: task.assignedBy || "",
    });

    const submit = () => {
        onSave({
            ...task,
            ...form,
            assignedOn: task.assignedOn || now(),
            status: task.status || "Assigned",
            statusUpdatedOn: task.statusUpdatedOn || now(),
        });
    };

    return (
        <div style={modalOverlay}>
            <div style={modal}>
                <h4>{task.id ? "Edit Task" : "Add Task"}</h4>

                <input
                    style={input}
                    placeholder="Task"
                    value={form.task}
                    onChange={(e) =>
                        setForm({ ...form, task: e.target.value })
                    }
                />

                <input
                    style={input}
                    placeholder="Assigned By"
                    value={form.assignedBy}
                    onChange={(e) =>
                        setForm({ ...form, assignedBy: e.target.value })
                    }
                />

                <div style={modalActions}>
                    <button style={saveBtn} onClick={submit}>
                        Save
                    </button>
                    <button style={cancelBtn} onClick={onClose}>
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    );
};

/* ===== Styles ===== */
const card = {
    background: COLORS.surface,
    border: `1px solid ${COLORS.border}`,
    borderRadius: 10,
    padding: 20,
};

const header = {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 20,
};

const title = { color: COLORS.textPrimary };

const table = { width: "100%", borderCollapse: "collapse" };

const th = {
    padding: 10,
    borderBottom: `1px solid ${COLORS.border}`,
    color: COLORS.textSecondary,
};

const td = {
    padding: 10,
    borderBottom: `1px solid ${COLORS.border}`,
};

const select = {
    padding: 6,
    borderRadius: 6,
    border: "0px solid rgba(0,0,0,0)",
};

const addBtn = {
    background: COLORS.primary,
    color: COLORS.white,
    border: "none",
    borderRadius: 6,
    padding: "6px 12px",
};

const editBtn = {
    background: COLORS.hover,
    border: "none",
    borderRadius: 6,
    padding: "4px 10px",
};

const modalOverlay = {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.4)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
};

const modal = {
    background: "#fff",
    padding: 20,
    borderRadius: 10,
    width: 350,
};

const input = {
    width: "90%",
    marginBottom: 10,
    padding: 8,
};

const modalActions = {
    display: "flex",
    justifyContent: "flex-end",
    gap: 10,
};

const saveBtn = {
    background: COLORS.success,
    color: "#fff",
    border: "none",
    padding: "6px 14px",
};

const cancelBtn = {
    background: COLORS.error,
    color: "#fff",
    border: "none",
    padding: "6px 14px",
};

const STATUS_COLORS = {
    Assigned: "#2563EB",   // Blue
    Ongoing: "#D97706",    // Amber
    Pending: "#6B7280",    // Gray
    Completed: "#16A34A",  // Green
    Canceled: "#DC2626",   // Red
};

const now = () =>
    new Date().toISOString().slice(0, 16).replace("T", " ");

export default TaskList;
