import React, { useMemo, useState } from "react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
// import { saveAs } from "file-saver";
import { COLORS } from "../config/theme";

const EOD_DATA = [
    {
        id: 2,
        date: "2026-01-23",
        task: "UI fixes and validations for dashboard components",
        inTime: "10:00",
        outTime: "19:00",
        assignedBy: "Sumit Godse",
        remarks: "Pending review",
    },
];

const Reports = () => {
    const today = new Date();
    const [month, setMonth] = useState(today.getMonth());
    const [year, setYear] = useState(today.getFullYear());

    const filteredReports = useMemo(() => {
        return EOD_DATA.filter((r) => {
            const d = new Date(r.date);
            return d.getMonth() === month && d.getFullYear() === year;
        });
    }, [month, year]);

    /* ---------- DOWNLOAD EXCEL ---------- */
    const downloadExcel = () => {
        const worksheet = XLSX.utils.json_to_sheet(filteredReports);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "EOD Reports");

        const excelBuffer = XLSX.write(workbook, {
            bookType: "xlsx",
            type: "array",
        });

        const file = new Blob([excelBuffer], {
            type: "application/octet-stream",
        });

        // saveAs(file, `EOD_Report_${MONTHS[month]}_${year}.xlsx`);
    };

    /* ---------- DOWNLOAD PDF ---------- */
    const downloadPDF = () => {
        const doc = new jsPDF();

        doc.text(`EOD Reports - ${MONTHS[month]} ${year}`, 14, 16);

        autoTable(doc, {
            startY: 22,
            head: [["Date", "Task", "In", "Out", "Assigned By", "Remarks"]],
            body: filteredReports.map((r) => [
                r.date,
                r.task,
                r.inTime,
                r.outTime,
                r.assignedBy,
                r.remarks,
            ]),
        });

        doc.save(`EOD_Report_${MONTHS[month]}_${year}.pdf`);
    };


    return (
        <div style={{ padding: 20 }}>
            <h2 style={{ color: COLORS.textPrimary, marginBottom: 16 }}>
                EOD Reports
            </h2>

            {/* Filters + Actions */}
            <div style={filterBox}>
                <select value={month} onChange={(e) => setMonth(+e.target.value)} style={selectStyle}>
                    {MONTHS.map((m, i) => (
                        <option key={m} value={i}>{m}</option>
                    ))}
                </select>

                <select value={year} onChange={(e) => setYear(+e.target.value)} style={selectStyle}>
                    {[2024, 2025, 2026, 2027].map((y) => (
                        <option key={y} value={y}>{y}</option>
                    ))}
                </select>

                <div style={{ marginLeft: "auto", display: "flex", gap: 10 }}>
                    <button onClick={downloadExcel} style={excelBtn}>Excel</button>
                    <button onClick={downloadPDF} style={pdfBtn}>PDF</button>
                </div>
            </div>

            {/* Table */}
            {filteredReports.length === 0 ? (
                <div style={{ color: COLORS.textSecondary }}>
                    No reports found.
                </div>
            ) : (
                <table style={tableStyle}>
                    <thead>
                        <tr>
                            {["Date", "Task", "In", "Out", "Assigned By", "Remarks"].map((h) => (
                                <th key={h} style={thStyle}>{h}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {filteredReports.map((r) => (
                            <tr key={r.id}>
                                <td style={tdStyle}>{r.date}</td>
                                <td style={tdStyle}>{r.task}</td>
                                <td style={tdStyle}>{r.inTime}</td>
                                <td style={tdStyle}>{r.outTime}</td>
                                <td style={tdStyle}>{r.assignedBy}</td>
                                <td
                                    style={{
                                        ...tdStyle,
                                        color:
                                            r.remarks === "Completed"
                                                ? COLORS.success
                                                : COLORS.warning,
                                        fontWeight: 600,
                                    }}
                                >
                                    {r.remarks}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

/* ---------- STYLES ---------- */

const filterBox = {
    display: "flex",
    gap: 12,
    padding: 14,
    marginBottom: 20,
    background: COLORS.surface,
    border: `1px solid ${COLORS.border}`,
    borderRadius: 8,
};

const selectStyle = {
    padding: "8px 12px",
    borderRadius: 6,
    border: `1px solid ${COLORS.border}`,
};

const excelBtn = {
    background: "#16A34A",
    color: "#fff",
    border: "none",
    padding: "8px 14px",
    borderRadius: 6,
    cursor: "pointer",
};

const pdfBtn = {
    background: "#DC2626",
    color: "#fff",
    border: "none",
    padding: "8px 14px",
    borderRadius: 6,
    cursor: "pointer",
};

const tableStyle = {
    width: "100%",
    borderCollapse: "collapse",
    background: COLORS.surface,
    border: `1px solid ${COLORS.border}`,
    borderRadius: 8,
    overflow: "hidden",
};

const thStyle = {
    textAlign: "left",
    padding: 12,
    background: COLORS.softBlue,
    borderBottom: `1px solid ${COLORS.border}`,
};

const tdStyle = {
    padding: 12,
    borderBottom: `1px solid ${COLORS.border}`,
    color: COLORS.textPrimary,
};

const MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
];

export default Reports;
