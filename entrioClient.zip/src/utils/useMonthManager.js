// import { configureDataEnvironment } from "../../electron/data/dataConfigurer";
// import { appendJson } from "../../electron/data/fileManager";

// const env = configureDataEnvironment();

// const TASKS_FILE = path.join(env.dataPath, "tasks.json");
// const BACKUP_DIR = env.backupPath;


// export const insertTask = () => {
//     appendJson({
//         dataFilePath: TASKS_FILE,
//         backupDirPath: BACKUP_DIR,
//         record: {
//             id: Date.now(),
//             task: "UI validation",
//             status: "assigned",
//             assignedOn: new Date().toISOString(),
//             statusUpdatedOn: new Date().toISOString(),
//         },
//     });
// }