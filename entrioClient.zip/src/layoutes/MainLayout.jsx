import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "../features/navigators/Sidebar";
import Footer from "../features/navigators/Footer";

const pageTitleMap = {
  "/": "Dashboard",
  "/months": "Month Manager",
  "/eod": "EOD",
  "/report": "Report",
  "/settings": "Settings",
  "/help": "Help",
  "/tasklist": "Task List",
};

const MainLayout = () => {
  const location = useLocation();
  const pageName = pageTitleMap[location.pathname] || "Dashboard";

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "97vh", overflowY: "hidden"  }}>
      <div style={{ display: "flex", flexGrow: 1}}>
        <Sidebar />
        <main style={{ flexGrow: 1, padding: 20, background: "#FFFFFF", height: "80vh" }}>
          <Outlet />
        </main>
      </div>

      <Footer pageName={pageName} />
    </div>
  );
};

export default MainLayout;
