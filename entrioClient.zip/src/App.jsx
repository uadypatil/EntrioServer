import { BrowserRouter, Routes, Route } from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import MonthlySheet from "./pages/MonthlySheet";
import EOD from "./pages/EOD";
import Profile from "./pages/Profile";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import MainLayout from "./layoutes/MainLayout";
import MonthManager from "./pages/MonthManager";
import Help from "./pages/Help";
import TaskList from "./pages/TaskList";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<MainLayout />}>
          {/* <Route path="/" element={<MonthlySheet year={2026} month={0} />} /> */}
          <Route path="/" element={<Dashboard />} />
          <Route path="/eod" element={<EOD />} />
          <Route path="/months" element={<MonthManager />} />
          <Route path="/report" element={<Reports />} />
          <Route path="/help" element={<Help />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/tasklist" element={<TaskList />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
