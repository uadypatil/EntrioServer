import integrator from "./integrator";
import { EOD } from "../config/ApiConfigurer";

export const getAllEOD = () =>
  integrator({ method: "GET", url: EOD.GET_ALL });

export const getEODById = (id) =>
  integrator({ method: "GET", url: EOD.GET_BY_ID(id) });

export const createEOD = (data) =>
  integrator({ method: "POST", url: EOD.CREATE, body: data });

export const updateEOD = (id, data) =>
  integrator({ method: "PUT", url: EOD.UPDATE(id), body: data });

export const patchEOD = (id, data) =>
  integrator({ method: "PATCH", url: EOD.PATCH(id), body: data });

export const deleteEOD = (id) =>
  integrator({ method: "DELETE", url: EOD.DELETE(id) });

export const getEODByUser = (userId) =>
  integrator({ method: "GET", url: EOD.GET_BY_USER(userId) });

export const getEODByDate = (date) =>
  integrator({
    method: "GET",
    url: EOD.GET_BY_DATE(date),
  });

export const getTodayEOD = (userId) =>
  integrator({ method: "GET", url: EOD.GET_TODAY(userId) });

export const fillTodayEOD = (userId, data) => {
  integrator({ method: "POST", url: EOD.FILL_TODAY(userId), body: data });
}

export const patchTodayEOD = (userId, data) =>
  integrator({ method: "POST", url: EOD.PATCH_TODAY(userId), body: data });
