import integrator from "./integrator";
import { DESKTOP_USER } from "../config/ApiConfigurer";

export const getAllUsers = () =>
  integrator({ method: "GET", url: DESKTOP_USER.GET_ALL });

export const getUserById = (id) =>
  integrator({ method: "GET", url: DESKTOP_USER.GET_BY_ID(id) });

export const createUser = (data) =>
  integrator({ method: "POST", url: DESKTOP_USER.CREATE, body: data });

export const updateUser = (id, data) =>
  integrator({ method: "PUT", url: DESKTOP_USER.UPDATE(id), body: data });

export const deleteUser = (id) =>
  integrator({ method: "DELETE", url: DESKTOP_USER.DELETE(id) });
