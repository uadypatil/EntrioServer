import integrator from "./integrator";
import { MONTH_MANAGER } from "../config/ApiConfigurer";

export const getAllMonths = () =>
  integrator({ method: "GET", url: MONTH_MANAGER.GET_ALL });

export const getMonthById = (id) =>
  integrator({ method: "GET", url: MONTH_MANAGER.GET_BY_ID(id) });

export const createMonth = (data) =>
  integrator({ method: "POST", url: MONTH_MANAGER.CREATE, body: data });

export const updateMonth = (id, data) =>
  integrator({ method: "PUT", url: MONTH_MANAGER.UPDATE(id), body: data });

export const patchMonth = (id, data) =>
  integrator({ method: "PATCH", url: MONTH_MANAGER.PATCH(id), body: data });

export const deleteMonth = (id) =>
  integrator({ method: "DELETE", url: MONTH_MANAGER.DELETE(id) });

export const getMonthsByUser = (userId) =>
  integrator({ method: "GET", url: MONTH_MANAGER.GET_BY_USER(userId) });

export const getMonthsByYear = (year) =>
  integrator({ method: "GET", url: MONTH_MANAGER.GET_BY_YEAR(year) });
