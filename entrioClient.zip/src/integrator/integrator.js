import axios from "axios";
import { API_BASE_URL } from "../config/ApiConfigurer";

/**
 * Generic API Integrator Function using axios
 * @param {Object} options
 * @param {string} options.method - HTTP method (GET, POST, PUT, PATCH, DELETE)
 * @param {string} options.url - Endpoint URL (without base URL)
 * @param {Object} [options.body] - Request body
 * @param {Object} [options.params] - Query parameters
 * @param {Object} [options.headers] - Custom headers
 */
const integrator = async ({
  method = "GET",
  url,
  body = null,
  params = null,
  headers = {},
}) => {
  try {
    const config = {
      method,
      url: `${API_BASE_URL}${url}`,
      headers: {
        "Content-Type": "application/json",
        ...headers,
      },
      params,  // axios handles query params automatically
      data: body,  // axios uses `data` for request body
      validateStatus: (status) => status >= 200 && status < 300, // default
    };

    // For GET and HEAD requests, axios ignores `data`, so no problem there

    const response = await axios(config);

    return response.data; // axios automatically parses JSON response

  } catch (error) {
    // axios errors contain response data and status info
    if (error.response) {
      console.error(
        "API ERROR:",
        error.response.status,
        error.response.data || error.message
      );
      throw new Error(error.response.data || error.message);
    } else {
      console.error("API ERROR:", error.message);
      throw error;
    }
  }
};

export default integrator;
