// ================= BASE =================
export const API_BASE_URL = "http://localhost:8851/api";


// ===================================================
// ================= MONTH MANAGER ===================
// ===================================================

export const MONTHS_BASE = "/months";

export const MONTH_MANAGER = {
  GET_ALL: `${MONTHS_BASE}`,
  GET_BY_ID: (id) => `${MONTHS_BASE}/${id}`,
  CREATE: `${MONTHS_BASE}`,
  UPDATE: (id) => `${MONTHS_BASE}/${id}`,
  PATCH: (id) => `${MONTHS_BASE}/${id}`,
  DELETE: (id) => `${MONTHS_BASE}/${id}`,
  GET_BY_USER: (userId) => `${MONTHS_BASE}/user/${userId}`,
  GET_BY_YEAR: (year) => `${MONTHS_BASE}/year/${year}`,
};


// ===================================================
// ================== EOD IN OUT =====================
// ===================================================

export const EOD_BASE = "/eod";

export const EOD = {
  GET_ALL: `${EOD_BASE}`,
  GET_BY_ID: (id) => `${EOD_BASE}/${id}`,
  CREATE: `${EOD_BASE}`,
  UPDATE: (id) => `${EOD_BASE}/${id}`,
  PATCH: (id) => `${EOD_BASE}/${id}`,
  DELETE: (id) => `${EOD_BASE}/${id}`,
  GET_BY_USER: (userId) => `${EOD_BASE}/user/${userId}`,
  GET_BY_DATE: (date) => `${EOD_BASE}/date?date=${date}`,
  GET_TODAY: (userId) => `${EOD_BASE}/today/${userId}`,
  FILL_TODAY: (userId) => `${EOD_BASE}/today/${userId}`,
  PATCH_TODAY: (userId) => `${EOD_BASE}/today/${userId}`,
};

// ===================================================
// ================= DESKTOP USER ====================
// ===================================================

export const DESKTOP_USER_BASE = "/desktop-user";

export const DESKTOP_USER = {
  GET_ALL: `${DESKTOP_USER_BASE}`,
  GET_BY_ID: (id) => `${DESKTOP_USER_BASE}/${id}`,
  CREATE: `${DESKTOP_USER_BASE}`,
  UPDATE: (id) => `${DESKTOP_USER_BASE}/${id}`,
  DELETE: (id) => `${DESKTOP_USER_BASE}/${id}`,
};
