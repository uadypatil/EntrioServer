export const COLORS = {
  white: "#FFFFFF",
  surface: "#F5F7FA",
  border: "#E1E4E8",
  textPrimary: "#1F2937",
  textSecondary: "#6B7280",
  primary: "#2563EB",
  hover: "#DBEAFE",
  success: "#16A34A",
  warning: "#D97706",
  error: "#DC2626",
};
