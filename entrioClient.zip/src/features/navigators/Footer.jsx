import React, { useEffect, useState } from "react";
import { COLORS } from "../../config/theme";

const Footer = ({ pageName = "Dashboard" }) => {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <footer
      data-aos="fade-up"
      style={{
        height: 60,
        background: COLORS.surface,
        borderTop: `1px solid ${COLORS.border}`,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "0 12px", // tighter padding for exact corner alignment
        fontSize: 14,
        color: COLORS.textSecondary,
      }}
    >
      {/* LEFT: Action Buttons */}
      <div
        style={{
          display: "flex",
          gap: 8,
          alignItems: "center",
        }}
      >
        {/* Settings Button */}
        {/* <button
          style={{
            background: COLORS.border, // gray
            color: COLORS.textPrimary,
            border: "none",
            borderRadius: 2,
            padding: "6px 14px",
            fontWeight: 500,
            cursor: "pointer",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = COLORS.hover)}
          onMouseLeave={(e) => (e.currentTarget.style.background = COLORS.border)}
        >
          Settings
        </button> */}

        {/* Logout Button */}
        {/* <button
          style={{
            background: COLORS.error, // red
            color: COLORS.white,
            border: "none",
            borderRadius: 2,
            padding: "6px 14px",
            fontWeight: 500,
            cursor: "pointer",
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.background = "#B91C1C") // darker red
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.background = COLORS.error)
          }
        >
          Logout
        </button> */}
      </div>

      {/* RIGHT: Page Info */}
      <div
        style={{
          fontWeight: 600,
          color: COLORS.textPrimary,
          textAlign: "right",
        }}
      >
        {pageName} • {now.toLocaleDateString()} {now.toLocaleTimeString()}
      </div>
    </footer>
  );
};

export default Footer;
