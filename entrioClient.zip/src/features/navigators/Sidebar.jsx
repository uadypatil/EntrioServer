import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { COLORS } from "../../config/theme";

const tabs = [
  { path: "/", label: "Dashboard" },
  //{ path: "/months", label: "Month Manager" },
  { path: "/eod", label: "EOD" },
  { path: "/tasklist", label: "Task List" },
  { path: "/report", label: "Reports" },
  { path: "/help", label: "Help" },
  // { path: "/settings", label: "Settings" },
];

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <nav
      style={{
        width: 200,
        minWidth: 200,
        background: COLORS.surface,
        borderRight: `1px solid ${COLORS.border}`,
        padding: 20,
      }}
    >
      <h2 style={{ textAlign: "center", marginBottom: 30 }}>Entrio Dash</h2>

      {tabs.map((tab) => {
        const active = location.pathname === tab.path;
        return (
          <div
            key={tab.path}
            onClick={() => navigate(tab.path)}
            style={{
              padding: "12px 16px",
              marginBottom: 6,
              borderRadius: 8,
              cursor: "pointer",
              background: active ? COLORS.hover : "transparent",
              color: active ? COLORS.primary : COLORS.textSecondary,
              fontWeight: active ? 600 : 500,
            }}
          >
            {tab.label}
          </div>
        );
      })}
    </nav>
  );
};

export default Sidebar;
