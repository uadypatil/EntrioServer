// main.js (FRONTEND ONLY – browser)

(() => {
  console.log("Frontend main.js loaded");

  if (window.api && typeof window.api.ping === "function") {
    window.api.ping();
    console.log("Ping sent to Electron");
  } else {
    console.log("Electron API not available (browser mode)");
  }
})();
