// main.js (Electron MAIN process)

import { app, BrowserWindow, ipcMain } from "electron";
import path from "path";
import { fileURLToPath } from "url";

// ---- ESM replacement for __dirname ----
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const preloadPath = path.join(__dirname, "preload.js");

// ✅ IPC HANDLER (THIS WAS MISSING)
ipcMain.handle("ping", async () => {
  console.log("Ping received in main process");
  return "pong";
});

app.whenReady().then(() => {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: preloadPath,
      contextIsolation: true,
      nodeIntegration: false
    },
    title: 'Entrio | EOD and task list',
    icon: path.join(__dirname, 'public/icon.ico')
  });

  win.webContents.openDevTools();

  if (!app.isPackaged) {
    win.loadURL("http://localhost:5173");
  } else {
    win.loadFile(path.join(__dirname, "dist", "index.html"));
  }
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
