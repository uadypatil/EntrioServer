# Entrio

**Entrio** is a lightweight system for **task management** and **daily in–out time tracking**, helping teams and individuals stay productive and organized.

The name _Entrio_ comes from **entry + trio**, representing the three core elements of the system:

- Tasks
- Check-in time
- Check-out time

---

## Features

- ✅ Task list management
- ⏱️ Daily in–out time tracking
- 📅 Simple daily work logging
- 🚀 Lightweight and easy to use

---

## Versioning Strategy

# Entrio

**Entrio** is a lightweight system for **task management** and **daily in–out time tracking**, helping teams and individuals stay productive and organized.

The name _Entrio_ comes from **entry + trio**, representing the three core elements of the system:

- Tasks
- Check-in time
- Check-out time

---

## Features

- ✅ Task list management
- ⏱️ Daily in–out time tracking
- 📅 Simple daily work logging
- 🚀 Lightweight and easy to use

---

# Entrio UI – Theme & Versioning

## Theme Colors

Entrio UI follows a clean, professional color palette designed for enterprise-grade web applications.  
The theme emphasizes clarity, accessibility, and consistency across all UI components.

### Color Palette

| Color Name                         | Hex Code | Usage                                       |
| ---------------------------------- | -------- | ------------------------------------------- |
| White (Base Background)            | #FFFFFF  | Main application background                 |
| Light Gray (Surface)               | #F5F7FA  | Cards, panels, sections                     |
| Dark Gray (Borders / Dividers)     | #E1E4E8  | Borders, separators, outlines               |
| Charcoal (Primary Text)            | #1F2937  | Headings, primary text                      |
| Slate Gray (Secondary Text)        | #6B7280  | Subtext, labels, helper text                |
| Professional Blue (Primary Action) | #2563EB  | Primary buttons, links, active states       |
| Soft Blue (Hover / Accent)         | #DBEAFE  | Hover states, highlights, focus backgrounds |
| Muted Green (Success)              | #16A34A  | Success messages, confirmations             |
| Muted Amber (Warning)              | #D97706  | Warnings, caution alerts                    |
| Muted Red (Error)                  | #DC2626  | Error messages, destructive actions         |

### Design Principles

- Neutral backgrounds to reduce eye strain
- High contrast text for readability
- Minimal but clear accent colors
- Consistent semantic colors for status feedback

---

## Versioning Strategy

Entrio follows **Semantic Versioning (SemVer)**:

### Version Logic

- **MAJOR**: Breaking changes that may require updates to code.
- **MINOR**: New features that maintain backward compatibility.
- **PATCH**: Small bug fixes and minor improvements.

**Example:**

During early development, Entrio uses `0.x.x` versions indicating active development.

---

## React + Vite Setup

This project uses **React** with **Vite** for fast development with HMR.

### Official Plugins

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react)  
  Uses [Babel](https://babeljs.io/) (or [oxc](https://oxc.rs)) for Fast Refresh.

- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc)  
  Uses [SWC](https://swc.rs/) for Fast Refresh.

### React Compiler

The React Compiler is **not enabled** in this template because of its impact on dev & build performance.  
To enable it, see the [official documentation](https://react.dev/learn/react-compiler/installation).

### ESLint & TypeScript

For production development, it is recommended to use **TypeScript** with type-aware lint rules enabled.  
See the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for guidance on integrating TypeScript and [`typescript-eslint`](https://typescript-eslint.io).

---

## Getting Started

1. Install dependencies:

```bash
npm install
# or
yarn
```
